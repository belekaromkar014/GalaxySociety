package com.project.galaxysociety;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GalaxysocietyApplicationTests {

	@Test
	void contextLoads() {
	}

}
