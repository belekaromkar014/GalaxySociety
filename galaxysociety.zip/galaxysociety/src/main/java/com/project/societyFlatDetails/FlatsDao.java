package com.project.societyFlatDetails;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class FlatsDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	// Insert Data
	public void insertFlatDetails(Flats flats) {
		Session session = sessionFactory.openSession();
		session.save(flats);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	//Detele Data
	public void deleteFlatDetails(int flat_no) {
		Session session = sessionFactory.openSession();
		Flats flats = session.get(Flats.class, flat_no);
		session.delete(flats);
		Transaction transaction = session.beginTransaction();
		transaction.commit();	
	}
	
	// Update Data
	public void updateFlatDetails(Flats flats) {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(flats);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	// Get All Data 
	public List<Flats> getAllFlatDetails(){
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Flats.class);
		List<Flats> flat = criteria.list();
		return flat;
	}
	
	// Get Specific Data by Flat No
	public Flats getFlatDetails(int flat_no) {
		Session session = sessionFactory.openSession();
		Flats flat = session.get(Flats.class, flat_no);
		return flat;
	}
	 
	// Get Specific Data by Flat Owner Name
	public Flats getFlatRecord(String flat_owner_name) {
		Session session = sessionFactory.openSession();
		Flats flats =session.get(Flats.class, flat_owner_name);
		return flats;
	}
	
	// Get Data by Wing
	public List<Flats> getFlatDetailsByWing(String wing) {
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Flats.class);
		criteria.add(Restrictions.eq("wing", wing));
		List<Flats> flats = criteria.list();
		return flats;
	}
	
/*	// OR Get Specific Data by Flat No
	public List<Flats> getFlatDetailsByFlatNo(int flat_no){
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Flats.class);
	    criteria.add(Restrictions.eq("flat_no",flat_no));
	    List<Flats> flat = criteria.list();
		return flat;
	}
*/
	
}
