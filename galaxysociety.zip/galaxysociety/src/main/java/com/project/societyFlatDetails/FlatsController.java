package com.project.societyFlatDetails;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FlatsController {

	@Autowired
	private FlatsService flatsService;

	@PostMapping("/addflatdetails")
	public Flats insertFlatDetails(@RequestBody Flats flats) {
		flatsService.insertFlatDetails(flats);
		return flats;
	}

	@DeleteMapping("/deleteflatdetails/{flat_no}")
	public String deleteFlatDetails(@PathVariable int flat_no) {
		flatsService.deleteFlatDetails(flat_no);
		return "Record delete successfully";
	}

	@PutMapping("/updateflatdetails")
	public Flats updateFlatDetails(@RequestBody Flats flats) {
		flatsService.updateFlatDetails(flats);
		return flats;
	}

	@GetMapping("/flatdetails")
	public List<Flats> getAllFlatDetails() {
		List<Flats> flat = flatsService.getAllFlatDetails();
		return flat;
	}

	@GetMapping("/flatdetails/{flat_no}")
	public Flats getFlatDetails(@PathVariable int flat_no) {
		Flats flat = flatsService.getFlatDetails(flat_no);
		return flat;
	}

	@GetMapping("/aflatdetails/{flat_owner_name}")
	public Flats getFlatRecord(@PathVariable String flat_owner_name) {
		Flats flats = flatsService.getFlatRecord(flat_owner_name);
		return flats;
	}

/*	@GetMapping("/bflatdetails/{flat_no}")
	public List<Flats> getFlatDetailsByFlatNo(@PathVariable int flat_no) {
		List<Flats> flat = flatsService.getFlatDetailsByFlatNo(flat_no);
		return flat;
	}
*/
	@GetMapping("/cflatdetails/{wing}")
	public List<Flats> getFlatDetailsByWing(@PathVariable String wing) {
		List<Flats> flats = flatsService.getFlatDetailsByWing(wing);
		return flats;
	}
}
