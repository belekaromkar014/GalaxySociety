package com.project.societyFlatDetails;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="flats")
public class Flats {
	
	private int sr_no;
	@Id
	private int flat_no;
	private String wing;
	private int floor_no;
	private String flat_owner_name;
	
	public Flats(int sr_no, int flat_no, String wing, int floor_no, String flat_owner_name) {
		super();
		this.sr_no = sr_no;
		this.flat_no = flat_no;
		this.wing = wing;
		this.floor_no = floor_no;
		this.flat_owner_name = flat_owner_name;
	}
	
	public int getSr_no() {
		return sr_no;
	}
	public void setSr_no(int sr_no) {
		this.sr_no = sr_no;
	}
	public int getFlat_no() {
		return flat_no;
	}
	public void setFlat_no(int flat_no) {
		this.flat_no = flat_no;
	}
	public String getWing() {
		return wing;
	}
	public void setWing(String wing) {
		this.wing = wing;
	}
	public int getFloor_no() {
		return floor_no;
	}
	public void setFloor_no(int floor_no) {
		this.floor_no = floor_no;
	}
	public String getFlat_owner_name() {
		return flat_owner_name;
	}
	public void setFlat_owner_name(String flat_owner_name) {
		this.flat_owner_name = flat_owner_name;
	}

	@Override
	public String toString() {
		return "Flats [sr_no=" + sr_no + ", flat_no=" + flat_no + ", wing=" + wing + ", floor_no=" + floor_no
				+ ", flat_owner_name=" + flat_owner_name + "]";
	}

	public Flats() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
