package com.project.societyFlatDetails;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FlatsService {
	
	@Autowired
	private FlatsDao flatsDao;
	
	public void insertFlatDetails(Flats flats) {
		flatsDao.insertFlatDetails(flats);
	}
	
	public List<Flats> getAllFlatDetails(){
		List<Flats> flat = flatsDao.getAllFlatDetails();
		return flat;
	}
	
	public void deleteFlatDetails(int flat_no) {
		flatsDao.deleteFlatDetails(flat_no);	
	}
	
	public void updateFlatDetails(Flats flats) {
		flatsDao.updateFlatDetails(flats);
	}
	
	public Flats getFlatDetails(int flat_no) {
		Flats flat = flatsDao.getFlatDetails(flat_no);
		return flat;
	}

	public Flats getFlatRecord(String flat_owner_name) {
		Flats flats =flatsDao.getFlatRecord(flat_owner_name);
		return flats;
	}
	
/*	public List<Flats> getFlatDetailsByFlatNo(int flat_no){
	    List<Flats> flat = flatsDao.getFlatDetailsByFlatNo(flat_no);
	    return flat;
	}
*/
	public List<Flats> getFlatDetailsByWing(String wing) {
		List<Flats> flats = flatsDao.getFlatDetailsByWing(wing);
		return flats;
	}
}
