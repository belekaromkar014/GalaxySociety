package com.project.amenities;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AmenitiesDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public void insertData(Amenities amenities) {
		Session session = sessionFactory.openSession();
		session.save(amenities);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	public List<Amenities> getAllData(){
		Criteria criteria = sessionFactory.openSession().createCriteria(Amenities.class);
		List<Amenities> amenities = criteria.list();
		return amenities;
	}
	
	public Amenities getSpecificData(String amenity_type) {
		Session session = sessionFactory.openSession();
		Amenities amenities = session.get(Amenities.class, amenity_type);
		return amenities;
	}
	
	public void updateData(Amenities amenities) {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(amenities);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	public void deleteData(String amenity_type) {
		Session session = sessionFactory.openSession();
		Amenities amenities = session.get(Amenities.class, amenity_type);
		session.delete(amenities);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	

}
