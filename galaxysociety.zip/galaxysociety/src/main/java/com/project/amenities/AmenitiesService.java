package com.project.amenities;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AmenitiesService {
	@Autowired
	private AmenitiesDao amenitiesDao;
	
	public void insertData(Amenities amenities) {
		amenitiesDao.insertData(amenities);
	}
	
	public List<Amenities> getAllData(){
		List<Amenities> amenities = amenitiesDao.getAllData();
		return amenities;
	}
	
	public Amenities getSpecificData(String amenity_type) {
		Amenities amenities =amenitiesDao.getSpecificData(amenity_type);
		return amenities;
	}
	
	public void updateData(Amenities amenities) {
		amenitiesDao.updateData(amenities);
	}
	
	public void deleteData(String amenity_type) {
		amenitiesDao.deleteData(amenity_type);
	}

}
