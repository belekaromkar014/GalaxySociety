package com.project.amenities;

import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AmenitiesController {
	@Autowired
	private AmenitiesService amenitiesService;
	
	@PostMapping("/insertdata")
	public void insertData(@RequestBody Amenities amenities) {
		amenitiesService.insertData(amenities);
	}
	
	@GetMapping("/getdata")
	public List<Amenities> getAllData(){
		List<Amenities> amenities = amenitiesService.getAllData();
		return amenities;
	}
	
	@GetMapping("/getspecificdata/{amenity_type}")
	public Amenities getSpecificData(@PathVariable String amenity_type) {
		Amenities amenities =amenitiesService.getSpecificData(amenity_type);
		return amenities;
	}
	
	@PutMapping("/updatedata")
	public void updateData(@RequestBody Amenities amenities) {
		amenitiesService.updateData(amenities);
	}
	
	@DeleteMapping("/deletedata/{amenity_type}")
	public void deleteData(@PathVariable String amenity_type) {
		amenitiesService.deleteData(amenity_type);
	}

}
