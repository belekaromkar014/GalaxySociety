package com.project.amenities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="amenities")
public class Amenities {
	
	@Id
	private String amenity_type;
	private int amenity_no;
	private String wing;
	private int floor_no;
	
	public Amenities(String amenity_type, int amenity_no, String wing, int floor_no) {
		super();
		this.amenity_type = amenity_type;
		this.amenity_no = amenity_no;
		this.wing = wing;
		this.floor_no = floor_no;
	}
	
	public String getAmenity_type() {
		return amenity_type;
	}
	public void setAmenity_type(String amenity_type) {
		this.amenity_type = amenity_type;
	}
	public int getAmenity_no() {
		return amenity_no;
	}
	public void setAmenity_no(int amenity_no) {
		this.amenity_no = amenity_no;
	}
	public String getWing() {
		return wing;
	}
	public void setWing(String wing) {
		this.wing = wing;
	}
	public int getFloor_no() {
		return floor_no;
	}
	public void setFloor_no(int floor_no) {
		this.floor_no = floor_no;
	}

	@Override
	public String toString() {
		return "Amenities [amenity_type=" + amenity_type + ", amenity_no=" + amenity_no + ", wing=" + wing
				+ ", floor_no=" + floor_no + "]";
	}
   
	public Amenities() {
		super();
		// TODO Auto-generated constructor stub
	}
}
