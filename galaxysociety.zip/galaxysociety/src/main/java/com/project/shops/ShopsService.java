package com.project.shops;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShopsService {
	@Autowired
	private ShopsDao shopsDao;
	
	public void insertShopData(Shops shops) {
		shopsDao.insertShopData(shops);
	}
	
	public void updateShopData(Shops shops) {
		shopsDao.updateShopData(shops);
	}
	
	public List<Shops> getAllShopData(){
		List<Shops> shops = shopsDao.getAllShopData();
		return shops;
	}
	
	public Shops getSpecificShopData(String shop_name) {
		Shops shops = shopsDao.getSpecificShopData(shop_name);
		return shops;
	}
	
	public void deleteShopData(String shop_name) {
		shopsDao.deleteShopData(shop_name);
	}

}
