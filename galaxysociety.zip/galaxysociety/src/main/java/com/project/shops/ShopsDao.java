package com.project.shops;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ShopsDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public void insertShopData(Shops shops) {
		Session session = sessionFactory.openSession();
		session.save(shops);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	public void updateShopData(Shops shops) {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(shops);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	public List<Shops> getAllShopData(){
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Shops.class);
		List<Shops> shops = criteria.list();
		return shops;
	}
	
	public Shops getSpecificShopData(String shop_name) {
		Session session = sessionFactory.openSession();
		Shops shops = session.get(Shops.class, shop_name);
		return shops;
	}
	
	public void deleteShopData(String shop_name) {
		Session session = sessionFactory.openSession();
		Shops shops = session.get(Shops.class, shop_name);
		session.delete(shops);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
	}
	
	

}
