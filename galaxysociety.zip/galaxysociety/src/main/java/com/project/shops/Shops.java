package com.project.shops;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="shops")
public class Shops {
    
	private int shop_no;
	@Id
	private String shop_name;
	private String shop_type;
	private String owner_name;
	private int floor_no;
	
	public Shops(int shop_no, String shop_name, String shop_type, String owner_name, int floor_no) {
		super();
		this.shop_no = shop_no;
		this.shop_name = shop_name;
		this.shop_type = shop_type;
		this.owner_name = owner_name;
		this.floor_no = floor_no;
	}

	public int getShop_no() {
		return shop_no;
	}

	public void setShop_no(int shop_no) {
		this.shop_no = shop_no;
	}

	public String getShop_name() {
		return shop_name;
	}

	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}

	public String getShop_type() {
		return shop_type;
	}

	public void setShop_type(String shop_type) {
		this.shop_type = shop_type;
	}

	public String getOwner_name() {
		return owner_name;
	}

	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}

	public int getFloor_no() {
		return floor_no;
	}

	public void setFloor_no(int floor_no) {
		this.floor_no = floor_no;
	}

	@Override
	public String toString() {
		return "Shops [shop_no=" + shop_no + ", shop_name=" + shop_name + ", shop_type=" + shop_type + ", owner_name="
				+ owner_name + ", floor_no=" + floor_no + "]";
	}

	public Shops() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
