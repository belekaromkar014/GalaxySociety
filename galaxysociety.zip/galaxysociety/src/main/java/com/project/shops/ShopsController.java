package com.project.shops;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShopsController {
	@Autowired
	private ShopsService shopsService;
	
	@PostMapping("/insertShopdata")
	public void insertShopData(@RequestBody Shops shops) {
		shopsService.insertShopData(shops);
	}
	
	@PutMapping("/updateShopdata")
	public void updateShopData(@RequestBody Shops shops) {
		shopsService.updateShopData(shops);
	}
	
	@GetMapping("/getallShopdata")
	public List<Shops> getAllShopData(){
		List<Shops> shops = shopsService.getAllShopData();
		return shops;
	}
	
	@GetMapping("/getspecificShopdata/{shop_name}")
	public Shops getSpecificShopData(@PathVariable String shop_name) {
		Shops shops = shopsService.getSpecificShopData(shop_name);
		return shops;
	}
	
	@DeleteMapping("/deleteShopdata/{shop_name}")
	public void deleteShopData(@PathVariable String shop_name) {
		shopsService.deleteShopData(shop_name);
	}

}



